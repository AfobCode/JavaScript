const hola =    "hola mundo";

function hola2() {
    console.log('hola desde la fn');
}